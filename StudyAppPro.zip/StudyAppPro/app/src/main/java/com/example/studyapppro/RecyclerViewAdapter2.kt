package com.example.studyapppro

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
//import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.item_row1.view.*

class RecyclerViewAdapter2 (private val activity:Activity, private val  headers2:Array<Array<String>>): RecyclerView.Adapter<RecyclerViewAdapter2.ItemViewHolder>() {
    private lateinit var builder: AlertDialog.Builder

    class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        return ItemViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.item_row1,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        //val color=colors[position]
        val title = headers2[position][0]
        val subject = headers2[position][1]
        val detial = headers2[position][2]

        holder.itemView.apply {
            first_text_android.text = title

            second_android.text = subject
            first_text_android.setOnClickListener() { alert(title, detial) }
            second_android.setOnClickListener() { alert(title, detial) }

        }
    }

    fun alert(t: String, d: String) {

        builder = AlertDialog.Builder(activity)
        builder.setTitle(t)
            .setMessage(d)
            .setCancelable(true) // dialog box in cancellable
            // set positive button
            //take two parameters dialogInterface and an int

            .setNegativeButton("OK") { dialogInterface, it ->


                dialogInterface.cancel()

            }

            // show the builder
            .show()
    }//end of alert function

    override fun getItemCount() = headers2.size
}


    //Could you please explain the idea of Card Views