package com.example.studyapppro

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    lateinit var Kotlin_Button:Button
    lateinit var Android_Button:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //Intilize buttons
        Kotlin_Button=findViewById(R.id.go_to_kotlin)
        Android_Button=findViewById(R.id.go_to_android)
        //set on click listener for buttons:
        Kotlin_Button.setOnClickListener(){
                val intent = Intent(this,Kotlin::class.java)
                startActivity(intent)

            }
        Android_Button.setOnClickListener(){
            val intent2=Intent(this,Android::class.java)
            startActivity(intent2)
        }


    }
}