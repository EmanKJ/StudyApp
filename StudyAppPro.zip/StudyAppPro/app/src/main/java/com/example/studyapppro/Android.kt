package com.example.studyapppro

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar

class Android : AppCompatActivity() {
    private lateinit var clMain: ConstraintLayout;//This variable to control the menu

    //This array includes the information about the lessons we need to display
    //each sub-array include a specific lesson, the title store in first index, then a short illustration of the title in the second index.
    //Third index includes information that will be display in the alert message
    val headers2= arrayOf(arrayOf("Initializing UI Elements","Try modifying the function we have created in the video to assign a random color to the Text View.",
        "Create 4 more text views and assign a random color to each one. See the video for more information: https://login.codingdojo.com/m/451/14128/101319"),
        arrayOf("Resource Files","Touche upon some resource files in the Project Overview"," Here, we will take a closer look at the colors.xml and themes.xml files. Making changes to these files allows us to set a base color for every UI Element (more on those later) we create."),
        arrayOf("Running on Physical Device","Students will be able to deploy an android application unto a physical device","There is also a way to connect your device to Android Studio wirelessly.\n" +
                "\n" +
                "If you prefer a wireless connection, you can find the details here: https://developer.android.com/studio/run/device"),
        arrayOf("Snackbar","We can use a Snackbar to display alerts in our application.","Go back to your Button App and find a way to incorporate a Snackbar. https://login.codingdojo.com/m/451/14129/101324"),
        arrayOf("Lists and Arrays Review","Take a few minutes to review Lists and Arrays.","When you are ready, create an immutable variable named 'colors' of data type List and populate it with ten colors of your choice."),
        arrayOf("Saving / Restoring Instance States","Store and retrieve data even after the destruction of the Activity ","Saving and restoring instances allows us to enable screen rotation without having to worry about losing data."),
        arrayOf("Shared Preferences","Shared Preferences allow us to save data to the user's device. ","To use Shared Preferences, we first have to declare our Shared Preferences variable."))
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_android)

        val myRV2=findViewById<RecyclerView>(R.id.rvMain_android)//Access the recycler view
        myRV2.adapter=RecyclerViewAdapter2(this,headers2)//connect recycler view with adapter
        myRV2.layoutManager= LinearLayoutManager(this)

    }
    //--------------------
    //This function makes the menu appear to the user:
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }
    //This function specify the action that will happen when the user click on item of the menu:
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.option1 -> {
                val intent0 = Intent(this,MainActivity::class.java)
                startActivity(intent0)
            }
            R.id.option2 -> {
                val intentA= Intent(this,Android::class.java)
                startActivity(intentA)

            }
            R.id.option3 -> {
                val intentK = Intent(this,Kotlin::class.java)
                startActivity(intentK)
            }
        }
        return super.onOptionsItemSelected(item)
    }
}