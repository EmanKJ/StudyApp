package com.example.studyapppro

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar


class Kotlin : AppCompatActivity() {

    //This array includes the information about the lessons we need to display
    //each sub-array include a specific lesson, the title store in first index, then a short illustration of the title in the second index.
    //Third index includes information that will be display in the alert message
    val headers= arrayOf(arrayOf("var and vla","Declaring variable",
        "Variables labeled with the val keyword are immutable, meaning they cannot be reassigned later.Variables with the var keyword are mutable and can be changed anytime."),
        arrayOf("User Input","Getting user input","We simply create a variable that holds the input, then get the user input with readLine()"),
        arrayOf("Strings","String concatenation, interpolation and methods","String concatenation refers to combining strings (or other data types) with the use of a + sign\nString Interpolation, on the other hand, allows us to inject variables into a string"),
        arrayOf("Data Types","understanding data types","Data types incled Int, Float, Boolean, and Strings. For moore information visit: https://login.codingdojo.com/m/451/14125/101267"),
        arrayOf("Basic operations","performing math operation in kotlin","It is important to avoid dividing by zero, as it would lead to a crash."),
        arrayOf("Maps","Maps allow us to create key value pairs.","If we wanted to assign seats at a table, we could number each chair, then add a name to each number in our Map."),
        arrayOf("If Statement","It used for conditions","We use if statements to guide our program in the right direction."))
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kotlin)
        val myRV=findViewById<RecyclerView>(R.id.rvMain_kotlin)//Access the recyvler view
        myRV.adapter=RecyclerViewAdapter1(this,headers)//connect recycler view with adapter
        myRV.layoutManager= LinearLayoutManager(this)
    }
    //This function makes the menu appear to the user:
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }
    //This function specify the action that will happen when the user click on item of the menu:
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.option1 -> {
                val intent0 = Intent(this,MainActivity::class.java)
                startActivity(intent0)
            }
            R.id.option2 -> {
                val intentA= Intent(this,Android::class.java)
                startActivity(intentA)

            }
            R.id.option3 -> {
                val intentK = Intent(this,Kotlin::class.java)
                startActivity(intentK)
            }
        }
        return super.onOptionsItemSelected(item)
    }

}